import 'package:unyo/domain/entities/anime.dart';
import 'package:unyo/domain/entities/anime_details.dart';
import 'package:unyo/domain/entities/user.dart';

abstract class AnimeRepository {
  Future<(bool, List<Anime>)> getRecentlyReleasedAnimes(int page, User loggedUser);
  Future<(bool, List<Anime>)> getTrendingAnimes(int page, User loggedUser);
  Future<(bool, List<Anime>)> getPopularAnimes(int page, User loggedUser);
  Future<(bool, List<Anime>)> getRecentlyCompletedAnimes(int page, User loggedUser);
  Future<(bool, List<Anime>)> getUpcomingAnimes(int page, User loggedUser);
  Future<Map<String, List<Anime>>> getCalendarReleases(int page, User loggedUser);
  Future<(bool, AnimeDetails)> getAnimeDetails(Anime selectedAnime, User loggedUser);
  Future<Map<String, (bool, List<String>)>> getUserAnimeAdvancedSearchFilters();
  Future<List<Anime>> performAnimeAdvancedSearch(
    String query,
    List<String> selectedGenres,
    String? selectedSeason,
    String? selectedFormat,
    int? selectedYear,
    String? selectedAiringStatus,
    String sort,
    int page,
    User loggedUser
  );
  Future<List<String>> getMediaCoverImages(User loggedUser);
}
