// Dart dependencies
import 'dart:async';

// External dependencies
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:bloc/bloc.dart';
import 'package:logger/logger.dart';

// Internal dependencies
import 'package:unyo/application/cubits/effect_mixin.dart';
import 'package:unyo/application/states/home_state.dart';
import 'package:unyo/core/di/locator.dart';
import 'package:unyo/core/enums/selected_menu_option.dart';
import 'package:unyo/core/enums/service.dart';
import 'package:unyo/core/notification/anime_notifier.dart';
import 'package:unyo/core/notification/manga_notifier.dart';
import 'package:unyo/core/notification/media_list_notifier.dart';
import 'package:unyo/core/notification/menu_bar_notifier.dart';
import 'package:unyo/core/notification/user_notifier.dart';
import 'package:unyo/application/effects/app_effects.dart';
import 'package:unyo/data/models/anilist_user_model.dart';
import 'package:unyo/data/models/local_user_model.dart';
import 'package:unyo/data/repositories/anime_repository_anilist.dart';
import 'package:unyo/data/repositories/repositories.dart';
import 'package:unyo/domain/entities/anime.dart';
import 'package:unyo/domain/entities/manga.dart';
import 'package:unyo/domain/entities/media_list.dart';
import 'package:unyo/domain/entities/user.dart';

class HomeCubit extends Cubit<HomeState> with EffectMixin<HomeState> {
  // Repositories
  final UserRepositoryAnilist _userRepositoryAnilist;
  final AnimeRepositoryAnilist _animeRepositoryAnilist;
  // Notifiers / Subscriptions
  final UserNotifier _loggedUserNotifier;
  final MenuBarNotifier _menuBarNotifier;
  final AnimeNotifier _selectedAnimeNotifier;
  final MangaNotifier _selectedMangaNotifier;
  final MediaListNotifier _selectedMediaListNotifier;
  late StreamSubscription<User> _newLoggedUserSubscription;
  final Logger _logger = sl<Logger>();

  HomeCubit(
    this._loggedUserNotifier,
    this._selectedAnimeNotifier,
    this._selectedMangaNotifier,
    this._selectedMediaListNotifier,
    this._userRepositoryAnilist,
    this._animeRepositoryAnilist,
    this._menuBarNotifier,
  ) : super(
        HomeState(
          loggedUser: UserModel.empty(),
          selectedMenuOption: SelectedMenuOption.home,
          continueWatching: [],
          continueReading: [],
          mediaCoverImages: [],
          isLoading: true,
          userLoaded: false,
        ),
      ) {
    _init();
  }

  @override
  HomeState copyStateWithEffects(HomeState state, List<AppEffect> effects) {
    return state.copyWith(effects: effects);
  }

  @override
  Logger get logger => _logger;

  @override
  Future<void> close() {
    _newLoggedUserSubscription.cancel();
    return super.close();
  }

  void _init() {
    _newLoggedUserSubscription = _loggedUserNotifier.userStream.listen((
      loggedUser,
    ) async {
      emit(
        state.copyWith(loggedUser: loggedUser),
      );
      if (!state.userLoaded) {
        await _getUserInfo(loggedUser);
        await _getMediaCoverImages(loggedUser);
        _menuBarNotifier.showMenuBar(true);
        emit(state.copyWith(userLoaded: true, isLoading: false));
      }
    });
  }

  void selectMenuOption(SelectedMenuOption option) {
    emit(state.copyWith(selectedMenuOption: option));
  }

  void navigateToAnimeDetails(Anime anime, MediaList mediaList) {
    _logger.i("Navigating to Anime Details of ${anime.title.userPreferred}");
    _selectedAnimeNotifier.updateSelectedAnime(anime);
    _selectedMediaListNotifier.updateSelectedMediaList(mediaList);
    pushRouteEffect(path: "/animedetails");
  }

  void navigateToMangaDetails(Manga manga, MediaList mediaList) {
    _logger.i("Navigating to Manga Details of ${manga.title.userPreferred}");
    _selectedMangaNotifier.updateSelectedManga(manga);
    _selectedMediaListNotifier.updateSelectedMediaList(mediaList);
    pushRouteEffect(path: "/mangadetails");
  }

  void navigateToUserAnimeList(BuildContext context) {
    _logger.i("Navigating to User Anime List");
    pushRouteEffect(path: "/userlist?type=anime");
  }

  void navigateToUserMangaList(BuildContext context) {
    _logger.i("Navigating to User Manga List");
    pushRouteEffect(path: "/userlist?type=manga");
  }

  Future<void> _getUserInfo(User user) async {
    try {
      switch (user) {
        case AnilistUserModel anilistUserModel:
          _logger.i("Fetching Anilist User lists");
          List<Anime> watchingList = await _userRepositoryAnilist
              .getUserWatchingList(anilistUserModel);
          List<Manga> readingList = await _userRepositoryAnilist
              .getUserReadingList(anilistUserModel);
          emit(
            state.copyWith(
              continueWatching: watchingList,
              continueReading: readingList,
            ),
          );
        case LocalUserModel localUserModel:
      }
    } catch (e, stackTrace) {
      handleError("Error fetching user info: $e", stackTrace: stackTrace);
      replaceRouteEffect(path: "/login");
    }
  }

  Future<void> _getMediaCoverImages(User loggedUser) async {
    try {
      switch (loggedUser.settings.service) {
        case Service.anilist:
          _logger.i("Fetching Media Cover Images from AniList");
          List<String> mediaCoverImages = await _animeRepositoryAnilist.getMediaCoverImages(loggedUser);
          emit(state.copyWith(mediaCoverImages: mediaCoverImages));
        case Service.mal:
          _logger.i("Fetching Media Cover Images from MyAnimeList");
        case Service.shikimori:
          _logger.i("Fetching Media Cover Images from Shikimori");
        case Service.kitsu:
          _logger.i("Fetching Media Cover Images from Kitsu");
        case Service.simkl:
          _logger.i("Fetching Media Cover Images from Simkl");
      }
    } catch (e, stackTrace) {
      handleError("Error fetching media cover images: $e", stackTrace: stackTrace);
    }
  }

}
