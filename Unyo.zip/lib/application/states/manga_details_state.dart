import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:k3vinb5_aniyomi_bridge/jmodels/jpage.dart';
import 'package:k3vinb5_aniyomi_bridge/jmodels/jschapter.dart';
import 'package:k3vinb5_aniyomi_bridge/jmodels/jsmanga.dart';
import 'package:unyo/application/cubits/effect_mixin.dart';
import 'package:unyo/application/effects/app_effects.dart';
import 'package:unyo/domain/entities/manga.dart';
import 'package:unyo/domain/entities/extension.dart';
import 'package:unyo/domain/entities/media_character.dart';
import 'package:unyo/domain/entities/media_list.dart';
import 'package:unyo/domain/entities/user.dart';

part 'manga_details_state.freezed.dart';

@freezed
abstract class MangaDetailsState with _$MangaDetailsState implements HasEffects{
  const factory MangaDetailsState({
    required User loggedUser,
    required MediaList selectedMediaList,
    required Manga selectedManga,
    required int progress,
    required int score,
    required int repeat,
    required (bool, List<MediaCharacter>) characters,
    required (bool, List<Manga>) recommendations,
    required List<String> banners,
    required String alternateImage,
    required Set<Extension> installedExtensions,
    required bool userLoaded,
    required Extension? selectedExtension,
    // relations
    // voice actors
    required List<JSManga> extensionMangaResults,
    required List<JSChapter> extensionEpisodeResults,
    required List<JPage> extensionVideoResults,
    @Default(<AppEffect>[]) List<AppEffect> effects,
  }) = _MangaDetailsState;

  const MangaDetailsState._();

  @override
  List<AppEffect> get stateEffects => effects;
}
